$(function() {

    var table;

    table = $('.table-sort').DataTable({
        "ordering": false
    });
});
