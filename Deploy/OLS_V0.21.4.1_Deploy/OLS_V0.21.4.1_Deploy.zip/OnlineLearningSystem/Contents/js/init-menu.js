$(function () {
    //[禁用权限验证]
    //OLS.renderMenu(false);
    OLS.renderMenu(true);
});
