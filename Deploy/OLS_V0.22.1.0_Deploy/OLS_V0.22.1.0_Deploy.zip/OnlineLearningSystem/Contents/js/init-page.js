$(function () {

    window.name = location.pathname;

    rowResponse();

});